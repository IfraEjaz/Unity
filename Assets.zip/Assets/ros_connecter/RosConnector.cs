using UnityEngine;
using Unity.Robotics.ROSTCPConnector;

public class RosConnector : MonoBehaviour
{
    ROSConnection ros;

    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.Connect("10.0.2.15", 10000);//172.17.0.2

        Debug.Log("Attempting to connect to ROS...");
    }
}

