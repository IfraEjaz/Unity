using Unity.Robotics.ROSTCPConnector;
using Unity.Robotics.ROSTCPConnector.MessageGeneration;
using RosMessageTypes.Geometry;
using UnityEngine;

public class TurtleBotController : MonoBehaviour
{
    ROSConnection ros;
    public string topicName = "/cmd_vel";
    
    public float linearSpeed = 0.5f;    // Forward movement
    public float angularSpeed = 0.0f;   // No rotation

    private float timeElapsed;

    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.RegisterPublisher<TwistMsg>(topicName);
    }

    void Update()
    {
        timeElapsed += Time.deltaTime;

        // Move robot forward in Unity (smooth straight-line motion)
        transform.Translate(Vector3.forward * linearSpeed * Time.deltaTime);

        // Publish Twist message to ROS every 0.5 seconds
        if (timeElapsed > 0.5f)
        {
            TwistMsg twist = new TwistMsg(
                new Vector3Msg(linearSpeed, 0, 0),    // Linear velocity: forward
                new Vector3Msg(0, 0, angularSpeed)    // Angular velocity: zero
            );

            ros.Publish(topicName, twist);
            timeElapsed = 0;
        }
    }
}

